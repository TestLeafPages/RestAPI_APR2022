package mock;

import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import static com.github.tomakehurst.wiremock.client.WireMock.*;

import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.response.Response;

public class CreateIncident {
	@BeforeMethod
	public void incidentStub() {
		stubFor(post("/api/now/table/incident")
				.willReturn(
				aResponse()
				.withStatus(201)
				.withHeader("content-type", "application/json")
				.withBody("{\"short_description\":\"Laptop is Down\",\"category\":\"Hardware\"}")
				));
	}
	
	@Test
	public void incidentCreation() {
		
		RestAssured.baseURI = "http://localhost:8080/api/now/table/incident";
		
		RestAssured.authentication = RestAssured.basic("admin", "v*CJ@eHh3Ls1");
		
		Response response = RestAssured.given()
											.contentType(ContentType.JSON)
									   .when()
									   .post()
									   .then()
									   .statusCode(204)
									   .extract().response();
		System.out.println(response.statusCode());
		response.prettyPrint();
	}

}
