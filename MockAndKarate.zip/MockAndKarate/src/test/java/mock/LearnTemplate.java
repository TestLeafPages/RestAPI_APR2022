package mock;

import org.testng.annotations.Test;

import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.response.Response;

public class LearnTemplate {

	@Test
	public void incidentCreation() {
		RestAssured.baseURI = "http://localhost:8080/testleaf/training/course";
			Response response = RestAssured 
				.given()
				.queryParam("course_name", "REST-Assured")
				.queryParam("Mode_Of_Learning", "Online")
				.contentType(ContentType.JSON)
				.when()
				.get()
				.then()
				.statusCode(200)
				.extract().response();
		System.out.println(response.statusCode());
		response.prettyPrint();
}
}
